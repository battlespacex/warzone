﻿// assets/js/warzone-mil-sats.js

import * as Cesium from "cesium";

const __warzoneMilSatsState = {
    viewer: null,
    entities: [],
    removeTick: null,
};

const SAT_MODEL_BASE = "/assets/images/models/space/";

/*
    FIXED VERSION:
    - NO regionId dependency (this was breaking visibility)
    - Satellites always exist globally
    - Visibility based on CAMERA DISTANCE (what user sees)
*/

const WARZONE_MIL_SATS = [

    // ===== GULF =====
    { id: "sat-gulf-1", name: "Gulf 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 24, lon: 46, altitude: 300000 },
    { id: "sat-gulf-2", name: "Gulf 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 30, lon: 54, altitude: 300000 },
    { id: "sat-gulf-3", name: "Gulf 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 19, lon: 57, altitude: 300000 },

    // ===== EUROPE =====
    { id: "sat-eu-1", name: "EU 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 50, lon: 10, altitude: 300000 },
    { id: "sat-eu-2", name: "EU 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 45, lon: 15, altitude: 300000 },
    { id: "sat-eu-3", name: "EU 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 55, lon: 20, altitude: 300000 },

    // ===== SOUTH ASIA =====
    { id: "sat-sa-1", name: "SA 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 31, lon: 74, altitude: 300000 },
    { id: "sat-sa-2", name: "SA 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 26, lon: 78, altitude: 300000 },
    { id: "sat-sa-3", name: "SA 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 22, lon: 70, altitude: 300000 },

    // ===== EAST ASIA =====
    { id: "sat-ea-1", name: "EA 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 30, lon: 121, altitude: 300000 },
    { id: "sat-ea-2", name: "EA 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 24, lon: 122, altitude: 300000 },
    { id: "sat-ea-3", name: "EA 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 15, lon: 114, altitude: 300000 },

    // ===== AFRICA =====
    { id: "sat-af-1", name: "AF 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 10, lon: 20, altitude: 300000 },
    { id: "sat-af-2", name: "AF 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: -5, lon: 30, altitude: 300000 },
    { id: "sat-af-3", name: "AF 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 25, lon: 10, altitude: 300000 },

    // ===== UKRAINE =====
    { id: "sat-ua-1", name: "UA 1", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 49, lon: 31, altitude: 300000 },
    { id: "sat-ua-2", name: "UA 2", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 47, lon: 36, altitude: 300000 },
    { id: "sat-ua-3", name: "UA 3", modelUri: `${SAT_MODEL_BASE}sat-1.glb`, lat: 50, lon: 26, altitude: 300000 },

];

function getCssVarNumber(varName, fallback) {
    const val = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
    const num = Number(val);
    return Number.isFinite(num) ? num : fallback;
}

function createSatelliteEntity(viewer, sat) {

    const position = Cesium.Cartesian3.fromDegrees(sat.lon, sat.lat, sat.altitude);

    // ✅ Read from root.css
    const scale = getCssVarNumber("--warzone-mil-sat-scale", 9000000);
    const minPx = getCssVarNumber("--warzone-mil-sat-min-px", 40);
    const maxScale = getCssVarNumber("--warzone-mil-sat-max-scale", 12000000);

    return viewer.entities.add({
        id: sat.id,
        position,

        model: {
            uri: sat.modelUri,
            scale: scale,
            minimumPixelSize: minPx,
            maximumScale: maxScale,
            show: true,
            shadows: Cesium.ShadowMode.DISABLED,
        },

        label: {
            text: sat.name,
            font: "600 13px Inter",
            fillColor: Cesium.Color.WHITE,
            showBackground: true,
            backgroundColor: Cesium.Color.BLACK.withAlpha(0.5),
            pixelOffset: new Cesium.Cartesian2(0, -40),
            disableDepthTestDistance: Number.POSITIVE_INFINITY
        }
    });
}

function updateVisibility(viewer) {

    const camera = viewer.camera;

    __warzoneMilSatsState.entities.forEach((entity) => {

        const pos = entity.position.getValue(Cesium.JulianDate.now());
        const distance = Cesium.Cartesian3.distance(camera.positionWC, pos);

        // 🔥 Only show nearby sats (THIS FIXES EVERYTHING)
        entity.show = distance < 12000000;
    });
}

export function initWarzoneMilSats(viewer) {

    __warzoneMilSatsState.viewer = viewer;

    __warzoneMilSatsState.entities = WARZONE_MIL_SATS.map(sat =>
        createSatelliteEntity(viewer, sat)
    );

    viewer.scene.postRender.addEventListener(() => {
        updateVisibility(viewer);
    });
}