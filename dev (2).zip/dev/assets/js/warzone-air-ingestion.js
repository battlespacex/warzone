﻿import { upsertLiveTrack, clearLiveTrack } from "./warzone-live-fighter.js";
import { isLayerEnabled } from "./warzone-layers.js";

const AIRPLANES_LIVE_URL = "https://api.airplanes.live/v2/mil";
const POLL_INTERVAL_MS = 15000;
const FETCH_TIMEOUT_MS = 9000;
const TRACK_STALE_MS = 90000;

const SOURCE_NAME = "airplanes.live";
const SOURCE_PRIORITY = {
    airplanes_live: 100,
};

let __pollTimer = null;
let __isFetching = false;

const __sourceTrackStore = new Map();
const __canonicalTrackStore = new Map();
const __activeTrackKeys = new Set();

function nowMs() {
    return Date.now();
}

function asFiniteNumber(value, fallback = 0) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeString(value = "") {
    return String(value || "").replace(/\s+/g, " ").trim();
}

function normalizeCallsign(value = "") {
    return normalizeString(value).replace(/^\.+|\.+$/g, "");
}

function getSourcePriority(source = "") {
    return SOURCE_PRIORITY[source] || 0;
}

function fetchWithTimeout(url, options = {}, timeoutMs = FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), timeoutMs);

    return fetch(url, {
        ...options,
        signal: controller.signal,
        cache: "no-store",
    }).finally(() => {
        window.clearTimeout(timer);
    });
}

function classifySubtype(record = {}) {
    const typeCode = normalizeString(record.t || record.type || "").toLowerCase();
    const desc = normalizeString(record.desc || record.category || record.r || "").toLowerCase();
    const callsign = normalizeCallsign(record.flight || "").toLowerCase();
    const haystack = [typeCode, desc, callsign].filter(Boolean).join(" ");

    // AWACS / AEW&C / early warning
    if (/(awacs|aew&c|aewc|airborne early warning|early warning|e-3|e3|sentry|e-7|e7|wedgetail|kj-2000|kj2000|kj-500|kj500|saab 340 aew|saab 2000 erieye|erieye|e-2|e2|hawkeye|a-50|a50|a-100|a100|phalcon|netra)/.test(haystack)) {
        return "awacs";
    }

    // Recon / SIGINT / ELINT / maritime patrol / surveillance
    if (/(rc-135|rc135|rivet joint|cobra ball|combat sent|ep-3|ep3|aries|p-3|p3|orion|p-8|p8|poseidon|il-20|il20|tu-214r|tu214r|recon|reconnaissance|surveillance|maritime patrol|mpa|sigint|elint|sentinel r1|global express isr|saab swordfish)/.test(haystack)) {
        return "recon";
    }

    // ISR / battlefield intelligence / special mission
    if (/(isr|intelligence|battlefield surveillance|ground surveillance|jstars|e-8|e8|ags|alliance ground surveillance|mq-4c|mq4c|triton|rq-4|rq4|global hawk|hermes 900|heron tp|special mission)/.test(haystack)) {
        return "isr";
    }

    // Tanker / refueler
    if (/(kc-135|kc135|kc-46|kc46|kc-10|kc10|a330 mrtt|voyager kc2|voyager kc3|il-78|il78|yy-20|yy20|tanker|refuel|refueller|refuelling|aerial refuel|air to air refuel)/.test(haystack)) {
        return "tanker";
    }

    // Transport / airlift / logistics
    if (/(c-17|c17|globemaster|c-5|c5|galaxy|c-130|c130|hercules|a400m|atlas|an-124|an124|ruslan|an-12|an12|an-26|an26|an-32|an32|il-76|il76|y-20|y20|c-2|c2|c-27j|c27j|spartan|cn-235|cn235|c295|transall|transport|airlift|airlifter|cargo|logistics|tactical airlift)/.test(haystack)) {
        return "transport";
    }

    // Bombers / strike bombers / gunships
    if (/(b-1|b1|lancer|b-2|b2|spirit|b-52|b52|stratofortress|tu-95|tu95|bear|tu-160|tu160|blackjack|tu-22m|tu22m|backfire|h-6|h6|badger|su-24|su24|fencer|su-34|su34|fullback|fb-111|gunship|ac-130|ac130|spectre|spooky|stinger ii|bomber|strategic bomber|strike bomber)/.test(haystack)) {
        return "bomber";
    }

    // UAV / UCAV / drones
    if (/(drone|uav|ucav|uas|mq-1|mq1|predator|mq-9|mq9|reaper|mq-20|mq20|avenger|rq-1|rq1|rq-4|rq4|global hawk|rq-7|rq7|shadow|rq-170|rq170|sentinel|mq-4c|mq4c|triton|tb2|bayraktar|akinci|anka|aksungur|heron|hermes|wing loong|wingloong|ch-4|ch4|ch-5|ch5|wj-700|wj700|loong|shahed|mohajer|ababil|switchblade|lancet|orlan|forpost|okhotnik)/.test(haystack)) {
        return "uav";
    }

    // Helicopters / gunships / rotorcraft
    if (/(heli|helicopter|rotary wing|rotorcraft|gunship|ah-1|ah1|cobra|ah-64|ah64|apache|uh-60|uh60|black hawk|blackhawk|hh-60|hh60|mh-60|mh60|seahawk|ch-47|ch47|chinook|ch-53|ch53|stallion|super stallion|king stallion|uh-1|uh1|huey|v-22|v22|osprey|mi-8|mi8|mi-17|mi17|hip|mi-24|mi24|hind|mi-28|mi28|havoc|ka-27|ka27|helix|ka-29|ka29|ka-31|ka31|ka-52|ka52|alligator|z-9|z9|z-10|z10|z-19|z19|z-20|z20|nh90|aw101|merlin|aw159|wildcat|lynx|ec665|tiger|h145m|hal dhruv|lch|prahchand|light combat helicopter)/.test(haystack)) {
        return "helicopter";
    }

    // Trainers
    if (/(trainer|advanced trainer|jet trainer|t-6|t6|t-38|t38|hawk|m-346|m346|yak-130|yak130|jl-10|jl10|l-15|l15|k-8|k8|kt-1|kt1|pc-21|pc21)/.test(haystack)) {
        return "trainer";
    }

    // Fighters / interceptors / multirole / attack jets
    if (/(fighter|interceptor|multirole|air superiority|combat aircraft|f\/a-18|fa-18|fa18|hornet|super hornet|f-14|f14|tomcat|f-15|f15|eagle|strike eagle|f-16|f16|falcon|f-22|f22|raptor|f-35|f35|lightning ii|a-10|a10|warthog|f-117|f117|nighthawk|su-27|su27|flanker|su-30|su30|su-35|su35|su-57|su57|mig-21|mig21|mig-23|mig23|mig-25|mig25|mig-29|mig29|mig-31|mig31|fulcrum|foxhound|j-7|j7|j-8|j8|j-10|j10|j-11|j11|j-15|j15|j-16|j16|j-20|j20|fc-1|fc1|jf-17|jf17|thunder|tejas|rafale|mirage 2000|mirage|typhoon|eurofighter|gripen|f-2|f2|kfir|lavi|jas 39)/.test(haystack)) {
        return "fighter";
    }

    return "fighter";
}

function buildCanonicalKey(track = {}) {
    const icao24 = normalizeString(track.icao24 || "").toLowerCase();
    if (icao24) return `icao24:${icao24}`;

    const callsign = normalizeCallsign(track.callsign || "").toLowerCase();
    if (callsign) return `callsign:${callsign}`;

    return `synthetic:${track.track_key}`;
}

function buildTrackKey(record = {}) {
    const hex = normalizeString(record.hex || "").toLowerCase();
    if (hex) return `apl-${hex}`;

    const callsign = normalizeCallsign(record.flight || "").toLowerCase();
    if (callsign) return `apl-${callsign.replace(/[^a-z0-9]+/g, "-")}`;

    const lat = asFiniteNumber(record.lat, 0).toFixed(3);
    const lon = asFiniteNumber(record.lon, 0).toFixed(3);
    return `apl-${lat}-${lon}`;
}

function normalizeAirplanesLiveRecord(record = {}) {
    const trackKey = buildTrackKey(record);
    const subtype = classifySubtype(record);
    const callsign = normalizeCallsign(record.flight || "");
    const altitudeFeet = asFiniteNumber(record.alt_baro, 0);
    const titleBase = callsign || normalizeString(record.r || record.hex || "Military Aircraft");

    return {
        track_key: trackKey,
        icao24: normalizeString(record.hex || "").toLowerCase(),
        callsign,
        title: titleBase,
        source_name: SOURCE_NAME,
        source: "airplanes_live",
        category: "military",
        subcategory: subtype,
        lat: asFiniteNumber(record.lat, NaN),
        lon: asFiniteNumber(record.lon, NaN),
        altitude_ft: altitudeFeet,
        speed_kts: asFiniteNumber(record.gs, 0),
        heading_deg: asFiniteNumber(record.track, 0),
        occurred_at: new Date().toISOString(),
        timestamp: nowMs(),
        metadata: {
            type: normalizeString(record.t || record.type || ""),
            registration: normalizeString(record.r || ""),
            source_type: normalizeString(record.type || ""),
            seen_seconds: asFiniteNumber(record.seen, 0),
            seen_pos_seconds: asFiniteNumber(record.seen_pos, 0),
            db_flags: asFiniteNumber(record.dbFlags, 0),
        },
    };
}

function mergeTrack(existing, incoming) {
    if (!existing) {
        return {
            ...incoming,
            sources: [incoming.source],
        };
    }

    const incomingPriority = getSourcePriority(incoming.source);
    const existingPriority = getSourcePriority(existing.source);
    const incomingTs = asFiniteNumber(incoming.timestamp, 0);
    const existingTs = asFiniteNumber(existing.timestamp, 0);

    const shouldPreferIncoming =
        incomingTs > existingTs ||
        (incomingTs === existingTs && incomingPriority >= existingPriority);

    const merged = {
        ...(shouldPreferIncoming ? existing : incoming),
        ...(shouldPreferIncoming ? incoming : existing),
    };

    merged.sources = Array.from(
        new Set([...(existing.sources || [existing.source]).filter(Boolean), incoming.source].filter(Boolean))
    );

    if (!merged.track_key) {
        merged.track_key = incoming.track_key || existing.track_key;
    }

    return merged;
}

function isTrackRenderable(track = {}) {
    return Number.isFinite(track.lat) && Number.isFinite(track.lon);
}

function clearAllPublicAirTracks() {
    for (const trackKey of __activeTrackKeys) {
        clearLiveTrack(trackKey);
    }
    __activeTrackKeys.clear();
    __sourceTrackStore.clear();
    __canonicalTrackStore.clear();
}

function cleanupStaleTracks() {
    const cutoff = nowMs() - TRACK_STALE_MS;

    for (const [canonicalKey, track] of __canonicalTrackStore.entries()) {
        if (asFiniteNumber(track.timestamp, 0) >= cutoff) continue;

        __canonicalTrackStore.delete(canonicalKey);
        if (track?.track_key) {
            __activeTrackKeys.delete(track.track_key);
            clearLiveTrack(track.track_key);
        }
    }
}

async function fetchAirplanesLiveRecords() {
    const response = await fetchWithTimeout(AIRPLANES_LIVE_URL);

    if (!response.ok) {
        throw new Error(`airplanes.live request failed (${response.status})`);
    }

    const payload = await response.json();
    return Array.isArray(payload?.ac) ? payload.ac : [];
}

async function refreshPublicAirTracks() {
    if (__isFetching) return;
    __isFetching = true;

    try {
        if (!isLayerEnabled("aircraft")) {
            clearAllPublicAirTracks();
            return;
        }

        const records = await fetchAirplanesLiveRecords();
        const seenThisPass = new Set();

        for (const record of records) {
            const normalized = normalizeAirplanesLiveRecord(record);
            if (!isTrackRenderable(normalized)) continue;

            const canonicalKey = buildCanonicalKey(normalized);
            const merged = mergeTrack(__canonicalTrackStore.get(canonicalKey), normalized);

            __sourceTrackStore.set(normalized.track_key, normalized);
            __canonicalTrackStore.set(canonicalKey, merged);
            seenThisPass.add(merged.track_key);

            upsertLiveTrack(merged);
            __activeTrackKeys.add(merged.track_key);
        }

        for (const trackKey of Array.from(__activeTrackKeys)) {
            if (seenThisPass.has(trackKey)) continue;

            const relatedCanonical = Array.from(__canonicalTrackStore.values()).find((track) => track.track_key === trackKey);
            if (!relatedCanonical) {
                __activeTrackKeys.delete(trackKey);
                clearLiveTrack(trackKey);
            }
        }

        cleanupStaleTracks();
    } catch (error) {
        console.warn("[warzone-air-ingestion] refresh failed:", error);
    } finally {
        __isFetching = false;
    }
}

export function startPublicAirIngestion() {
    if (__pollTimer) return;

    refreshPublicAirTracks();
    __pollTimer = window.setInterval(refreshPublicAirTracks, POLL_INTERVAL_MS);
}

export function stopPublicAirIngestion() {
    if (__pollTimer) {
        window.clearInterval(__pollTimer);
        __pollTimer = null;
    }

    clearAllPublicAirTracks();
}
