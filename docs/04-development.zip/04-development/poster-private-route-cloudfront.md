# Poster private-route CloudFront gate

The repository does not contain the production CloudFront distribution or its infrastructure-as-code configuration. The `/poster` build is therefore deliberately unlinked and non-indexable, but it is not access-controlled until this viewer-request function is deployed.

Create a CloudFront Function from the following template. Replace `__POSTER_ACCESS_TOKEN__` during deployment from the deployment secret store; never commit or expose the real value in frontend JavaScript.

```js
function handler(event) {
    var request = event.request;
    var uri = request.uri;
    var isPosterPage = uri === "/poster" || uri === "/poster/" || uri === "/pages/poster.html";

    if (!isPosterPage) {
        return request;
    }

    var access = request.querystring && request.querystring.access;
    if (!access || access.value !== "__POSTER_ACCESS_TOKEN__") {
        return {
            statusCode: 404,
            statusDescription: "Not Found",
            headers: {
                "cache-control": { value: "no-store, max-age=0" },
                "content-type": { value: "text/plain; charset=utf-8" },
                "x-robots-tag": { value: "noindex, nofollow, noarchive, nosnippet" }
            },
            body: "Not Found"
        };
    }

    delete request.querystring.access;
    request.uri = "/pages/poster.html";
    return request;
}
```

Deployment configuration:

1. Generate a high-entropy token outside Git and substitute it only in the deployed function code.
2. Publish the function and associate it with the StratOps distribution's viewer-request event for the behavior that includes `/poster*`.
3. Keep the function association ahead of the cache lookup. The function validates every request, then removes the token from the origin/cache key and rewrites the clean route to `/pages/poster.html`.
4. Attach a response headers policy for `/poster*` that adds `X-Robots-Tag: noindex, nofollow, noarchive, nosnippet` to successful origin responses.
5. Invalidate `/poster` and `/pages/poster.html` after deploying the function and build.
6. Verify `/poster` returns 404 without the token and `/poster?access=<deployment-token>` returns the tool.

The shared `/assets/images/poster/` and `/assets/fonts/` files remain regular static assets. They do not expose the tool or the access token.

The included Express static server also fails closed in production unless `POSTER_ACCESS_TOKEN` is configured and supplied as `?access=...`. Local development bypasses that check. This protects Express-hosted deployments only; it does not replace the CloudFront function for the stated S3/CloudFront production architecture.

## Frontend deployment

Use the repository deployment command so content-addressed CSS and JavaScript are uploaded before the HTML that references them:

```powershell
npm run deploy:frontend -- -Bucket <bucket-name> -DistributionId <distribution-id>
npm run deploy:frontend -- -Bucket <bucket-name> -DistributionId <distribution-id> -Execute
```

The first command is an AWS dry run. Review it before adding `-Execute`. The script builds by default, validates both generated poster documents and their referenced assets, uploads HTML last with no-cache metadata, invalidates only the poster routes and their current CSS/JavaScript, waits for completion, and verifies the live responses. It deliberately does not use `aws s3 sync --delete`; deleting an older hashed asset while cached HTML still references it recreates the unstyled-page failure.
